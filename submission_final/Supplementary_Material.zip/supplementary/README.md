# Does Rubric-Guided Refinement Improve Prompts from Small-Model Optimizers?

Accepted in **IEEE Access**. [Read the paper](https://doi.org/10.1109/ACCESS.2026.3757210).

Code and results for Meta-Prompted Instruction Refinement (MPIR).

## Abstract

Meta-Prompted Instruction Refinement (MPIR) asks a language model to score an optimized prompt against a rubric, rewrite it, and keep the rewrite only if it beats the original on validation questions. We re-test it after an earlier evaluation was found to have a validation leak, with a repaired, logged loop and decision rules fixed in advance. The scope is narrow: Qwen3-1.7B as target, 45 base prompts from three small-model optimizers, nine Big-Bench Hard tasks. With the 1.7B model refining its own prompts, the original treatment changed the prompt in 1 of 80 runs, but 93-95% of its candidates had lost the answer format, so the test could not separate a failed idea from a failed treatment. With the format protected (positive control: the gate accepted a known-good candidate in 24 of 26 cells), the rubric-guided variant won in 1 cell and lost in 3 under a lenient metric validated on 400 AI-labelled responses, whereas a rubric-free rewrite with the same protection gained +3.8 points on average (11 winning cells of 45); the paired difference is +3.7 points [+1.1, +6.8] in its favour. Qwen3-235B and GPT-6 Luna improved the prompts under protection (+7.3 and +3.4 points, nine cells, one run each), but a rubric-free rewrite reached similar gains. One answer-format exemplar changed strict accuracy by +19.5 (APE) and +42.3 (ProTeGi) points, mostly tag format, and identical prompts disagree on 6.5% of examples. The rubric is not shown to help; conclusions are limited to Qwen3 targets, nine tasks and these optimizers.

## Code and data

- [Supplementary material](https://github.com/millennials92/meta_prompted_instruction_refinement/blob/main/submission_final/Supplementary_Material.zip): code, experiment records, and protocol.
- [`mpir_study/`](https://github.com/millennials92/meta_prompted_instruction_refinement/tree/main/mpir_study/): refinement methods, evaluation, and analysis.
- [`results/revision/`](https://github.com/millennials92/meta_prompted_instruction_refinement/tree/main/results/revision/): experiment results.
- [`demos/data/`](https://github.com/millennials92/meta_prompted_instruction_refinement/tree/main/demos/data/) and [`demos/results/`](https://github.com/millennials92/meta_prompted_instruction_refinement/tree/main/demos/results/): data splits and saved prompts.
- [`BIG-Bench-Hard/`](https://github.com/millennials92/meta_prompted_instruction_refinement/tree/main/BIG-Bench-Hard/): benchmark materials.

See [`run_study.py`](https://github.com/millennials92/meta_prompted_instruction_refinement/blob/main/mpir_study/run_study.py) for experiment groups and [`client.py`](https://github.com/millennials92/meta_prompted_instruction_refinement/blob/main/mpir_study/client.py) for model endpoint configuration.

## License

[MIT License](https://github.com/millennials92/meta_prompted_instruction_refinement/blob/main/LICENSE). Bundled Big-Bench Hard and PromptWizard code retain their respective licenses.
