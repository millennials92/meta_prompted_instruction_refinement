# Archive

Earlier development notes and reviews are preserved here as historical records.
The current paper title, abstract, and DOI are in [README](../README.md).
